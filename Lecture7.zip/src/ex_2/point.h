#ifndef POINT_H
#define POINT_H

struct Point
{
    int x;
    int y;
};


Point addPoint(const Point& p1, const Point& p2);


#endif // POINT_H

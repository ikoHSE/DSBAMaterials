/*! \file       problem_n.cpp
 *  \author     Student Name
 *  \version    0.1
 *  \date       15.01.2019
 *
 *  Solution of the Problem N/Contest 1.
 *
 *  Task: <paste it here if you need it>
 *
 *  Input format: <paste it here if you need it>
 *
 *  Output format: <paste it here if you need it>
 */

int main()
{
    return 0;
}
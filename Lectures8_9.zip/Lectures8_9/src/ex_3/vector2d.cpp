
// this header goes first because this file is a main counterpart for the header
#include "vector2d.h"

#include <cmath>    // sqrt



void Vector2d::multByScalar(double z)
{
    x *= z;
    y *= z;
}

double Vector2d::calcLength()
{
    // if the value has not been calculated previously...
    if(length < 0)
        length = sqrt(x * x + y * y);

    return length;
}

Vector2d& Vector2d::multByScalarEnh(double z)
{
    x *= z;
    y *= z;

    return (*this);
}



//Vector2d& Vector2d::multByScalarEnh(double z)
//{
//    Vector2d& curInsta = *this;

//    curInsta.x *= z;
//    curInsta.y *= z;

//    return curInsta;
//}









//void Vector2d::multByScalar(/* Vector2d& v, */ double z)
//{
//    /* v.*/ x *= z;
//    /* v.*/ y *= z;
//}

//double Vector2d::calcLength(/* Vector2d& v */)
//{
//    // if the value has not been calculated previously...
//    if(/*v.*/length < 0)
//        /*v.*/length = sqrt(/*v.*/x * /*v.*/x + /*v.*/y * /*v.*/y);

//    return /*v.*/length;
//}






//void multByScalar(Vector2d& v, double z)
//{
//    v.x *= z;
//    v.y *= z;
//}

//Vector2d& multByScalarEnh(Vector2d& v, double z)
//{
//    v.x *= z;
//    v.y *= z;

//    return v;
//}



//std::ostream& operator<<(std::ostream& s, const Vector2d& v)
//{
//    s << '(' << v.x << ", " << v.y << ')';

//    return s;
//}


//double calcLength(/*const */Vector2d& v)
//{
//    // if the value has not been calculated previously...
//    if(v.length < 0)
//        v.length = sqrt(v.x * v.x + v.y * v.y);

//    return v.length;
//}

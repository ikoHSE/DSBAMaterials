﻿/*! \file       ex_.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       17.01.2019
 *
 *  Enhanced Vector2d Structure.
 */

#include <iostream>

#include "vector2d.h"

int main()
{
    Vector2d v1 = {2, 3, -1};
    Vector2d v2 = {3, 4, -1};

    double l1 = v1.calcLength();
    double l2 = v2.calcLength();

    v2.x = 10;
    double l1_2 = v2.calcLength();      // here l1_2 == 5, which is incorrect



    v1.multByScalar(10);
    v2.multByScalar(10);

    int a = 0;

    return 0;
}

/*! \file matrix.h
 *  Contains declaration of the clas Matrix and corresponding types.
 */

#ifndef MATRIX_H
#define MATRIX_H



#endif // MATRIX_H

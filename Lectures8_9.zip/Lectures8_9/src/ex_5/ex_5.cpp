﻿/*! \file       ex_5.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       07.02.2019
 *
 *  Matrix class definition. Version 1.
 */

#include <iostream>

#include "matrix.h"

int main()
{
    std::cout << "Let's do some matrices!\n";

    std::cout << "\n\nBye-bye!\n\n";
    return 0;
}

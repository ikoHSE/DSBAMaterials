
// this header goes first because this file is a main counterpart for the header
#include "vector2d.h"

#include <cmath>    // sqrt



Vector2d::Vector2d()
    : _x(0) , _y(0) , _length(-1)                   // right: initialization
{
    // _x = 0;                                      // correct, but less effecient:
    // _y = 0;                                      // re-initialization of an already
    // _length = -1;                                // initialized objects
}

Vector2d::Vector2d(double x, double y)
    : _x(x)
    , _y(y)
    , _length(-1)                                   // right: initialization
{
    // _x = x;                                      // correct, but less effecient...
    // _y = y;
    // _length = -1;
}



void Vector2d::multByScalar(double z)
{
    _x *= z;
    _y *= z;
}

double Vector2d::calcLength()
{
    // if the value has not been calculated previously...
    if(_length < 0)
        _length = sqrt(_x * _x + _y * _y);

    return _length;
}

Vector2d& Vector2d::multByScalarEnh(double z)
{
    _x *= z;
    _y *= z;

    return (*this);
}


// There are a lot of dead code bollow. //



//Vector2d::Vector2d()
//{
//    _x = 0;
//    _y = 0;
//    _length = -1;
//}

//Vector2d::Vector2d(double x, double y)
//{
//    _x = x;
//    _y = y;
//    _length = -1;
//}

//Vector2d& Vector2d::multByScalarEnh(double z)
//{
//    Vector2d& curInsta = *this;

//    curInsta.x *= z;
//    curInsta.y *= z;

//    return curInsta;
//}









//void Vector2d::multByScalar(/* Vector2d& v, */ double z)
//{
//    /* v.*/ x *= z;
//    /* v.*/ y *= z;
//}

//double Vector2d::calcLength(/* Vector2d& v */)
//{
//    // if the value has not been calculated previously...
//    if(/*v.*/length < 0)
//        /*v.*/length = sqrt(/*v.*/x * /*v.*/x + /*v.*/y * /*v.*/y);

//    return /*v.*/length;
//}






//void multByScalar(Vector2d& v, double z)
//{
//    v.x *= z;
//    v.y *= z;
//}

//Vector2d& multByScalarEnh(Vector2d& v, double z)
//{
//    v.x *= z;
//    v.y *= z;

//    return v;
//}



//std::ostream& operator<<(std::ostream& s, const Vector2d& v)
//{
//    s << '(' << v.x << ", " << v.y << ')';

//    return s;
//}


//double calcLength(/*const */Vector2d& v)
//{
//    // if the value has not been calculated previously...
//    if(v.length < 0)
//        v.length = sqrt(v.x * v.x + v.y * v.y);

//    return v.length;
//}

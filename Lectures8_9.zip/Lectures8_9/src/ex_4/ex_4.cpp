﻿/*! \file       ex_.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       17.01.2019
 *
 *  Enhanced Structure 2.
 */

#include <iostream>

#include "vector2d.h"

int main()
{
    //Vector2d v1 = {2, 3, -1};
    //Vector2d v2 = {3, 4, -1};



    return 0;
}

/*! \file vector2d.h
 *  Definition of the structure Vector2d (enhaced version 2).
 */

#ifndef VECTOR2D_H
#define VECTOR2D_H

#include <iostream>


struct Vector2d
{
public:
    //----< Methods >----

    Vector2d();                                     ///< Default Constructor.
    Vector2d(double x, double y);                   ///< Initialization constructor.

    void multByScalar(double z);                    ///< Multiplication.
    Vector2d& multByScalarEnh(double z);            ///< Enhanced multiplication.
    double calcLength();                            ///< Length calculation.

private:
    //----< Fields >----

    double _x;
    double _y;
    double _length;                                 ///< Stores the cached value of the vector's length.
}; // struct Vector2d



#endif // VECTOR2D_H

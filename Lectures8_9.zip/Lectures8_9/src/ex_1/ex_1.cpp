﻿/*! \file       ex_1.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       05.02.2019
 *
 *  Cinema Theatre.
 */

#include <iostream>
#include <string>
#include <sstream>
#include <vector>

// Define datatypes for representing rows and a sitting plan of a cinema hall
typedef std::vector<char> Row;
typedef std::vector<Row> SittingPlan;
typedef unsigned short UShort;
typedef std::pair<int, int> IntPair;

//------------------------------------------------------------------------------


/*!
 * \brief   inputRow() reads information about a single row from stdin object.
 * \return  a row object. An empty row means the end of the input process.
 */
Row inputRow()
{
    // string representation of a row
    std::string rowStr;
    std::getline(std::cin, rowStr);

    Row row;
    // what about an empty string? — simply return an "empty row",
    // which indicates that the input is over
    if(rowStr.empty())
        return row;

    // parse using stringstream (don't forget #include <sstream>)
    std::stringstream ss(rowStr);

    char ch;
    while( ss >> ch )
    {
        // can check here whether it is proper or not
        row.push_back(ch);
    }

    return row;
}


//------------------------------------------------------------------------------


/*!
 * \brief   inputSittingPlan() inputs a sitting plan of a cinema theater row by row.
 *          An empty row terminates the input.
 * \return  The sitting plan as a vector of vectors of ints, which is a matrix of a
 *          jagged array.
 */
SittingPlan inputSittingPlan()
{
    SittingPlan sitPlan;            // prepare an object for input data

    Row r = inputRow();             // reads the very first row
    while(r.size() /* != 0 */)      // repeat the loop while another row is not empty
    {
        sitPlan.push_back(r);       // add another row to the sitting plan
        r = inputRow();             // read the next row
    }

    return sitPlan;
}

//------------------------------------------------------------------------------

// one need to explain using the inline keyword here
inline bool isSold(char seat)
{
    return (seat == '1');

    //return (seat == '1') ? true : false;
//    if(seat == '1')
//        return true;

//    return false;
}

//------------------------------------------------------------------------------

void printRow(const Row& row)
{
    int sold = 0;
    int total = 0;

    for(char el : row )
    {
        ++total;
        char symb;

        //if(el == '1')   // DONE: to improve the logic of checking
        if(isSold(el))
        {
            ++sold;
            symb = '*';
        }
        else
            symb = '.';

        std::cout << symb;
    }

    // output statistics
    // we are not going to add a newline char
    std::cout << "\t\t(" << sold << '/' << total <<')';
}


//------------------------------------------------------------------------------

void printSittingPlan(const SittingPlan& sp)
{
    for( const Row& row : sp )
    {
        printRow(row);
        std::cout << '\n';
    }
}


//------------------------------------------------------------------------------

// Looks for a sequence of k free sits...
int findFreeFreq(const Row& row, UShort k)
{
    UShort freeCnt = 0;
    //
    for(UShort i = 0; i < row.size(); ++i)
    {
        if(!isSold(row[i]))     // if a seat is free
        {
            ++freeCnt;
            if(freeCnt == k)
                return (i - k + 1);
        }
        else
            freeCnt = 0;
    }

    return -1;
}

//------------------------------------------------------------------------------

//std::pair<int, int> findFreeFreq(const SittingPlan& sp, UShort k)
IntPair findFreeFreq(const SittingPlan& sp, UShort k)
{
    for(UShort i = 0; i < sp.size(); ++i)
    {
        //int findFreeFreq(Row& row, UShort k)
        const Row& row = sp[i];
        int freeCol = findFreeFreq(/*sp[i]*/row, k);
        if(freeCol != -1)
            return { i, freeCol };
    }

    return {-1, -1};        // there is no appropriate pair
}


int main()
{
    // test inputRow() method
    //Row r = inputRow();

    // test inputing sitting plan
    //SittingPlan sp = inputSittingPlan();

    // test printing a row
    //printRow(sp.at(0));

    // test printing the whole sitting plan
    //printSittingPlan(sp);

    // test searching a sequence of free seats
    //int res = findFreeFreq(sp.at(0), 2);

    // finally, bring the things together
    SittingPlan sp = inputSittingPlan();
    UShort k;
    std::cout << "Input k: ";
    std::cin >> k;
    IntPair res = findFreeFreq(sp, k);


    int a = 0;                      // a dummy object is needed for putting a breakpoint here
}

/*! \file vector2d.h
 *  Definition of the structure Vector2d.
 */

#ifndef VECTOR2D_H
#define VECTOR2D_H

#include <iostream>


struct Vector2d
{
    double x;
    double y;

    double length;      ///< Stores the cached value of the vector's length.
};


/// Multiplies the given vector \a v to the given number \a z.
void multByScalar(Vector2d& v, double z);

/// Multiplies the given vector \a v to the given number \a z.
/// \returns the vector \a itself.
Vector2d& multByScalarEnh(Vector2d& v, double z);


/// Overloading of the operator<< that allows to use the custom
/// datatype v in a context similar to: cout << v;
std::ostream& operator<<(std::ostream& s, const Vector2d& v);


/// Calculates the length of the given vector \a v.
/// Caches the calcuated value to be able to reuse it later.
/// Why don't we use const here?
double calcLength(/*const */Vector2d& v);






#endif // VECTOR2D_H

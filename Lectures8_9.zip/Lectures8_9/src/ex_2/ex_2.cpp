﻿/*! \file       ex_2.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       05.02.2019
 *
 *  From Structures to Classes.
 */

#include <iostream>

#include "vector2d.h"

int main()
{
    // create two vectors
    Vector2d v1 = {2, 3};
    Vector2d v2 = {3, 4};

    /* Vector2d v3 = */ multByScalar(v1, 10);   // applying transformation only
    //   ^^^
    //    it is not possible because multByScalar() returns nothing

    Vector2d v3 = multByScalarEnh(v2, 10);      // returns transofrmed object, which allows
                                                // using it in nested expression


    // output formatted representaion of Vector2d objects "in a natural form"
    (std::cout << "v1: ") << v1 << '\n';
    //std::ostream& operator<<(std::ostream& s, const Vector2d& v)


    int a = 0;

    return 0;
}




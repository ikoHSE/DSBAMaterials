
// this header goes first because this file is a main counterpart for the header
#include "vector2d.h"

#include <cmath>    // sqrt

void multByScalar(Vector2d& v, double z)
{
    v.x *= z;
    v.y *= z;
}

Vector2d& multByScalarEnh(Vector2d& v, double z)
{
    v.x *= z;
    v.y *= z;

    return v;
}



std::ostream& operator<<(std::ostream& s, const Vector2d& v)
{
    s << '(' << v.x << ", " << v.y << ')';

    return s;
}


double calcLength(/*const */Vector2d& v)
{
    // if the value has not been calculated previously...
    if(v.length < 0)
        v.length = sqrt(v.x * v.x + v.y * v.y);

    return v.length;
}

/*! \file
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       15.01.2019
 *  \copyright  2019
 *
 *  A collection of simple functions that illustrate some basic aspects
 *  of C++ programs.
 *
 *  Mind how this very comment is represented. We use a special sequence
 *  / *! (w/o spaces) at the beginning of the comment block in order to make
 *  this comment to be a Doxygen-valid comment (http://www.doxygen.nl/).
 */


#include <iostream> // std::cin, std::cout, std::endl
#include <climits>

//------------------------------------------------------------------------------

/*! Experiments on input/output and debugging */
void wshp2Ex1()
{
    using namespace std;

    /*std::*/
    cout << "Hello, World!\n";

    cout << "The maximum number of unsigned short is " << USHRT_MAX << endl;

    unsigned short num = 42;

    cout << "Enter the num = ";
    cin >> num;

    cout << "The value of the num var is " << num;

    //cin
    // /*std::*/cin
}

//------------------------------------------------------------------------------

/*! Asks for a name and prints a greeting. */
void lecture2Ex1()
{
    using std::string;
    using std::cout;
    using std::cin;

    string name;
    cout << "Your name: ";
    cin >> name;

    cout << "Hello, " << name << "!\n\n";
}

//------------------------------------------------------------------------------

/*! Illustrates different kinds of statements. */
void lecture2Ex2()
{
    using namespace std;                    // using statement

    string name;                            // declaration statement
    cout << "Your name: ";                  // expression statement
    cin >> name;                            // expression

    name = "Rostislav";                     // assignment statement

    cout << "Hello, " << name << "!\n\n";   // expression (complex)

    return;                                 // return statement
}


//------------------------------------------------------------------------------

/*! A scope of a statement block {...}. */
void lecture2Ex3()
{
    // TODO: try to debug this method by using breakpoints.

    int a = 0;          // visible by the end of the function

    {
        int b = 0;      // visible only by the end of the current block
    }

    std::cout << a;     // 0
    // std::cout << b;  // ERROR: b is not exists anymore
}


//------------------------------------------------------------------------------

/*! Numerical limits. */
void lecture2Ex4()
{
    using namespace std;

    cout << "Hello, World!\n\n";

    cout << "The sise of short is: " << sizeof(short) << endl;
    cout << "The sise of int is: " << sizeof(int) << endl;
    cout << "The sise of long is: " << sizeof(long) << endl;
    cout << "The sise of long long is: " << sizeof(long long) << endl;

    short iShort;
    int iInt;
    long iLong;
    long long iLongLong;

    cout << "The sise of variable of a short datatype is: " << sizeof(iShort) << endl;
    cout << "The sise of variable of a int datatype is: " << sizeof(iInt) << endl;
    cout << "The sise of variable of a long datatype is: " << sizeof(iLong) << endl;
    cout << "The sise of variable of a long long datatype is: " << sizeof(iLongLong) << endl;


    cout << "<climits> contains the following constants: \n";
    cout << "SHRT_MAX = " << SHRT_MAX << endl;
    cout << "INT_MAX = " << INT_MAX << endl;
    cout << "LONG_MAX = " << LONG_MAX << endl;
    cout << "LLONG_MAX = " << LLONG_MAX << endl;

    cout << "\n\n\nBye-bye!\n\n";
}

//------------------------------------------------------------------------------

/*! Research on the char datatype. */
void lecture2Ex5()
{
    using namespace std;

    cout << "Hello, World!\n\n";

    char ch = 'A';              // mind the character literal surrounded by single quotes
    int chInt = ch;
    cout << "The ASCII code for the charater '" << ch << "' is " << chInt << endl;

    ch = ch + 1;
    chInt = ch;
    cout << "New character '" << ch << "' and its ASCII code is " << chInt << endl;

    cout << "\n\nBye-bye!\n\n";
}


//------------------------------------------------------------------------------

/*! Floating-point numbers. */
void lecture2Ex6()
{
    using namespace std;
    cout << "Hello, World!\n\n";

    cout << "double's size is " << sizeof(double) << endl;


    double x = 10.0 / 3.0;

    //cout.setf(ios_base::fixed, ios_base::floatfield); // set fixed-point output
    cout << "x = " << x << endl;

    cout << "Exponential form: " << 3.21e+8 << endl;
    cout << "Exponential form (2): " << 7.14E-4 << endl;
    cout << "Exponential form (3): " << 3E5 << endl;
    cout << "Fixed-point form: " << 2.8 << endl;


    cout << "\n\nBye-bye!\n\n";
}

//------------------------------------------------------------------------------

/*! Precedence of operators demo. */
void lecture2Ex7()
{
    using namespace std;
    cout << "Hello, World!\n\n";

    int x = 2 + 3 * 4;
    int y = (2 + 3) * 4;

    cout << "x = " << x << ", y = " << y << endl;


    cout << "\n\nBye-bye!\n\n";
}

//------------------------------------------------------------------------------

/*! The Main Function of the Program. */
int main()
{
    // TODO: Uncomment any method you want to try.

    // lecture2Ex1();
    // lecture2Ex2();
    // lecture2Ex3();
    // lecture2Ex4();
    // lecture2Ex5();
    // lecture2Ex6();
    // lecture2Ex7();

    // wshp2_ex1();

    return 0;
}






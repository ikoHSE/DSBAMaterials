﻿/*! \file       ex_2.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       29.01.2019
 *
 *  Introduction to structures.
 *  Scopes of structures.
 */

#include <iostream>

// to put it in a separate header, e.g. mypoint.h
// and use #include <mypoint.h>

// Define a new custom datatype using the struct keyword
struct Point
{
    int x;
    int y;
};

void foo()
{
    struct Bar
    {
        int a;
        double b;
    };
    Bar b;
}

void bar()
{
    Point p;                    // accessible
    //Bar b;                    // inaccessible
}

void printPoint(const Point& p)
{
    std::cout << "(" << p.x << ", "
              << p.y << ")";

    // p.x = 10;                // p.x cannot be on the "left hand" of the assignment =
}

int main()
{

    Point p;                // default initialization (random values for x and y)
    Point p1 = { 10, 15 };  // init by a list of values (x = 10, y = 15 )
    Point p2 { 20, 25 };    // the same, new syntax as of C++11
    Point p3 = p1;          // init p3 by the value of an object p1 of the same type
    Point p4;
    p4 = p1;                // re-assign the value of p4 by p1 point

    std::cout << "p4 is: ";
    printPoint(p4);

    return 0;
}





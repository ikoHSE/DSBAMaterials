﻿/*! \file       ex_.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       17.01.2019
 *
 *  →
 */

#include <iostream>
#include <string>
#include <sstream>
#include <vector>


// Define datatypes for representing
typedef std::vector<int> Row;
typedef std::vector<Row> SittingPlan;

/*!
 * \brief   inputRow() reads an information about a single row from stdin object.
 * \return  a row object. An empty row means the end of the input process.
 */
Row inputRow()
{
    // string representation of a row
    std::string rowStr;
    std::getline(std::cin, rowStr);

    Row row;
    // what about an empty string? — simply return an "empty row",
    // which indicates that the input is over
    if(rowStr.empty())
        return row;


    // parse using stringstream (don't forget #include <sstream>)
    std::stringstream ss(rowStr);

    char ch;
    while( ss >> ch )
    {
        // can check here whether it is proper or not
        row.push_back(ch);
    }

    return row;
}


/*!
 * \brief   inputSittingPlan() inputs a sitting plan of a cinema theater row by row.
 *          Empty row terminates the input.
 * \return  The sitting plan as a vector of vectors of ints, which is a matrix of a
 *          jagged array.
 */
SittingPlan inputSittingPlan()
{
    SittingPlan sitPlan;            // prepare an object for input data

    Row r = inputRow();             // reads the very first row
    while(r.size() /* != 0 */)      // repeat the loop while another row is not empty
    {
        sitPlan.push_back(r);       // add another row to the sitting plan
        r = inputRow();             // read the next row
    }

    return sitPlan;
}


int main()
{
    // test inputRow() method
    //Row r = inputRow();

    // test inputing sitting plan
    SittingPlan sp = inputSittingPlan();

    int a = 0;                      // dummy object is needed to be able to put a breakpoint here
}
























//int main()
//{

//    // read line by line
//    std::string s;
//    //do
//    while(std::cin)  // [!> объяснить, что означает (true)
//    {
//        std::getline(std::cin, s);

//        if(s.size() == 0)
//            break;

//        std::stringstream ss(s);
//        //ss << s;

//        //while(!ss.eof()) // here can be a repetition of the last char
//        char ch;
//        char peekCh = ss.peek();
//        //while(ss.peek() != '\n'
////        while(peekCh != '\n'            // how it can be rewritten with for
////               && (ss >> ch))           // multiline for stepping individual expressions
//        while(ss >> ch)
//        {

//            peekCh = ss.peek();         // why is it -1 for the last iteration?
//            //ss >> ch;
//            int a = 0;
//        }

//        int a = 0;
//    }
//    //} while(s.length() != 0);

//    return 0;
//}

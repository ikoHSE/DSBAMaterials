﻿/*! \file       ex_1.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       29.01.2019
 *
 *  const-s
 *  vectors and matrices
 */

#include <iostream>


int main()
{
    int a = 15;

    const int b = 10;
    //b = 17;                   // can't modify a const object

    int const b1 = 10;

    return 0;
}

﻿/*! \file       ex_3.cpp
 *  \author     Sergey Shershakov
 *  \version    0.1
 *  \date       29.01.2019
 *
 *  Point Structure.
 */

#include <iostream>


struct Point
{
    int x;
    int y;
};


int main()
{
    Point p;                    // default
    Point p2 = {10, 20};        // init prior C++11
    Point p3 {15, 25};          // init since C++11
    Point p4 = p2;              // init by an object of the same type
    Point p5;                   // default
    p5 = p2;                    // assignment
    p5 = {1, 2};

    return 0;
}
